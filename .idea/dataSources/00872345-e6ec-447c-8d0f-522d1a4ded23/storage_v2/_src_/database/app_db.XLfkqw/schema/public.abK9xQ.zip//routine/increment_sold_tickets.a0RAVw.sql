create function increment_sold_tickets() returns trigger
    security definer
    language plpgsql
as
$$
begin
      update zones set sold_tickets = sold_tickets + 1 where id = new.zone_id;
      return new;
     end;
$$;

alter function increment_sold_tickets() owner to app_user;

